
namespace NTypeMatrixServices
{
  public class Menu
  {
    private List<NTypeMatrix> mem = new List<NTypeMatrix>();
    private int running = 0;
    public void Run()
    {
      running = 1;
      string? input;
      do
      {
        Console.WriteLine("");
        Console.WriteLine("| l: List matrix in memory");
        Console.WriteLine("| n: Add matrix to memory");
        Console.WriteLine("| u: Update matrix in memory");
        Console.WriteLine("| a: Add matrices");
        // Console.WriteLine("| s: Multiply matrix with scalar");
        Console.WriteLine("| g: Query a specific entry of a matrix");
        Console.WriteLine("| m: Multiply matrices");
        Console.WriteLine("| e: Close terminal");
        Console.Write("> ");

        input = Console.ReadLine();
        Console.WriteLine("");
        if (input == null)
        {
          continue;
        }

        switch (input.ToLower())
        {
          case "l":
            PrintMatrix(mem);
            break;
          case "n":
            NewMatrix(mem);
            break;
          case "u":
            UpdateMatrix(mem);
            break;
          case "a":
            MatrixAddition(mem);
            break;
          case "g":
            MatrixEntry(mem);
            break;
          // case "s":
          //   MatrixScalarMul(mem);
          //   break;
          case "m":
            MatrixMul(mem);
            break;
          case "e":
            running = 0;
            break;
          default:
            Console.WriteLine("! Unknown command.");
            break;
        }
      } while (running == 1);
    }

    private static bool ReadInt(out int result)
    {
      try
      {
        string? input = Console.ReadLine();
        if (input == null)
        {
          result = 0;
          return false;
        }
        result = Int16.Parse(input);
        return true;
      }
      catch (OverflowException)
      {
        Console.WriteLine("Number too large to parse.");
      }
      catch (FormatException)
      {
        Console.WriteLine("Cannot parse number.");
      }
      result = 0;
      return false;
    }
    private static bool ReadSize(out int size)
    {
      Console.Write("Enter matrix size: ");
      bool p = ReadInt(out size);
      if (!p)
      {
        size = 1;
        return false;
      }
      if (size <= 0)
      {
        size = 1;
        Console.WriteLine("! Invalid matrix size.");
        return false;
      }
      return true;
    }
    private static bool ReadIndex(out int index, int length)
    {
      Console.Write("Enter index (0-based): ");
      bool p = ReadInt(out index);
      if (!p)
      {
        index = 0;
        return false;
      }
      if (index < 0 || index >= length)
      {
        Console.WriteLine("! Index out of range.");
        return false;
      }
      return true;
    }
    private static void PrintMatrix(List<NTypeMatrix> mem)
    {
      Console.WriteLine($"? Matrix in memory: {mem.Count}");
      for (int i = 0; i < mem.Count; i++)
      {
        Console.WriteLine($"Matrix #{i + 1}");
        Console.WriteLine(mem.ElementAt(i).ToString());
      }
    }

    private static void NewMatrix(List<NTypeMatrix> mem)
    {
      bool p = ReadSize(out int size);
      if (!p) { return; }

      NTypeMatrix mat = new NTypeMatrix(size);
      mem.Add(mat);
      Console.WriteLine("? Matrix added.");
      Console.WriteLine(mat.ToString());
    }

    private static void UpdateMatrix(List<NTypeMatrix> mem)
    {
      bool p = ReadIndex(out int index, mem.Count);
      if (!p) { return; }

      p = ReadSize(out int size);
      if (!p) { return; }

      NTypeMatrix mat = new NTypeMatrix(size);
      mem[index] = mat;
      Console.WriteLine("? Matrix updated.");
      Console.WriteLine(mat.ToString());
    }

    private static void MatrixAddition(List<NTypeMatrix> mem)
    {
      bool p = ReadIndex(out int indexLeft, mem.Count);
      if (!p) { return; }
      p = ReadIndex(out int indexRight, mem.Count);
      if (!p) { return; }

      try
      {
        NTypeMatrix mat = mem.ElementAt(indexLeft) + mem.ElementAt(indexRight);
        mem.Add(mat);
        Console.WriteLine("? Matrix added.");
        Console.WriteLine(mat.ToString());
      }
      catch (NTypeMatrix.IncompatibleMatrixDimensionException)
      {
        Console.WriteLine("! Incompatible matrix dimension.");
      }
    }
    private static void MatrixEntry(List<NTypeMatrix> mem)
    {
      bool p = ReadIndex(out int index, mem.Count);
      if (!p)
      {
        return;
      }
      p = ReadIndex(out int row, mem.ElementAt(index).Size);
      if (!p)
      {
        return;
      }
      p = ReadIndex(out int col, mem.ElementAt(index).Size);
      if (!p)
      {
        return;
      }
      Console.WriteLine($"? ({row}, {col}) entry of matrix #{index}: {mem.ElementAt(index).Get(row, col)}");
    }
    // private static void MatrixScalarMul(List<NTypeMatrix> mem)
    // {

    //   bool p = ReadIndex(out int index, mem.Count);
    //   if (!p) { return; }
    //   Console.Write("Scale: ");
    //   p = ReadInt(out int scalar);
    //   if (!p) { return; }
    //   try
    //   {
    //     NTypeMatrix mat = mem.ElementAt(index) * scalar;
    //     mem.Add(mat);
    //     Console.WriteLine("? Matrix added.");
    //     Console.WriteLine(mat.ToString());
    //   }
    //   catch (NTypeMatrix.IncompatibleMatrixDimensionException)
    //   {
    //     Console.WriteLine("! Incompatible matrix dimension.");
    //   }
    // }

    private static void MatrixMul(List<NTypeMatrix> mem)
    {
      bool p = ReadIndex(out int indexLeft, mem.Count);
      if (!p) { return; }
      p = ReadIndex(out int indexRight, mem.Count);
      if (!p) { return; }

      try
      {
        NTypeMatrix mat = mem.ElementAt(indexLeft) * mem.ElementAt(indexRight);
        mem.Add(mat);
        Console.WriteLine("? Matrix added.");
        Console.WriteLine(mat.ToString());
      }
      catch (NTypeMatrix.IncompatibleMatrixDimensionException)
      {
        Console.WriteLine("! Incompatible matrix dimension.");
      }
    }
  }
}

