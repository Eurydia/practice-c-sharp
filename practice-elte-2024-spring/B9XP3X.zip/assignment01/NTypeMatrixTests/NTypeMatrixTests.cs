using static NTypeMatrixServices.NTypeMatrix;

namespace NTypeMatrixServices.UnitTest
{
    [TestClass]
    public class NTypeMatrixTests
    {
        #region INITIALIZATION
        [TestMethod]
        [ExpectedException(typeof(InvalidMatrixSizeException))]
        public void MatrixSizeZero()
        {
            NTypeMatrix mat = new NTypeMatrix(0);
        }
        [TestMethod]
        [ExpectedException(typeof(InvalidMatrixSizeException))]
        public void MatrixSizeNegative()
        {
            NTypeMatrix mat = new NTypeMatrix(-1);
        }
        [TestMethod]
        [ExpectedException(typeof(InvalidMatrixSizeException))]
        public void MatrixSizeSmallNegative()
        {
            NTypeMatrix mat = new NTypeMatrix(-1000);
        }

        [DataTestMethod]
        [DataRow(1)]
        [DataRow(2)]
        [DataRow(3)]
        [DataRow(4)]
        public void MatrixSizeValid(int size)
        {
            NTypeMatrix mat = new NTypeMatrix(size);
            Assert.IsTrue(mat.Size.Equals(size));
        }

        [DataTestMethod]
        [DataRow(100)]
        [DataRow(1000)]
        [DataRow(10000)]
        [DataRow(100000)]
        public void MatrixSizeValidLarge(int size)
        {
            NTypeMatrix mat = new NTypeMatrix(size);
            Assert.IsTrue(mat.Size.Equals(size));
        }
        #endregion
        #region INDEXING
        [TestMethod]
        [ExpectedException(typeof(MatrixIndexOutOfRange))]
        public void MatrixIndexInvalidRowTooLarge()
        {
            NTypeMatrix mat = new NTypeMatrix(3);
            mat.Get(4, 0);
        }

        [TestMethod]
        [ExpectedException(typeof(MatrixIndexOutOfRange))]
        public void MatrixIndexInvalidRowTooSmall()
        {
            NTypeMatrix mat = new NTypeMatrix(3);
            mat.Get(-1, 0);
        }

        [TestMethod]
        [ExpectedException(typeof(MatrixIndexOutOfRange))]
        public void MatrixIndexInvalidColTooLarge()
        {
            NTypeMatrix mat = new NTypeMatrix(3);
            mat.Get(0, 4);
        }

        [TestMethod]
        [ExpectedException(typeof(MatrixIndexOutOfRange))]
        public void MatrixIndexInvalidColTooSmall()
        {
            NTypeMatrix mat = new NTypeMatrix(3);
            mat.Get(0, -1);
        }
        [DataTestMethod]
        [DataRow(1)]
        [DataRow(2)]
        [DataRow(3)]
        [DataRow(4)]
        public void MatrixIndexDiagonalValid(int size)
        {
            NTypeMatrix mat = new NTypeMatrix(size);

            for (int i = 0; i < size; i++)
            {
                Assert.IsTrue(mat.Get(i, i).Equals(1));
            }
        }
        [DataTestMethod]
        [DataRow(1)]
        [DataRow(2)]
        [DataRow(3)]
        [DataRow(4)]
        public void MatrixIndexColFirstValid(int size)
        {
            NTypeMatrix mat = new NTypeMatrix(size);

            for (int i = 0; i < size; i++)
            {
                Assert.IsTrue(mat.Get(i, 0).Equals(1));
            }
        }
        [DataTestMethod]
        [DataRow(1)]
        [DataRow(2)]
        [DataRow(3)]
        [DataRow(4)]
        public void MatrixIndexColLastValid(int size)
        {
            NTypeMatrix mat = new NTypeMatrix(size);

            for (int i = 0; i < size; i++)
            {
                Assert.IsTrue(mat.Get(i, size - 1).Equals(1));
            }
        }
        #endregion

        #region ADDITION

        [TestMethod]
        [ExpectedException(typeof(IncompatibleMatrixDimensionException))]
        public void MatrixAdditionIncompatibaleSize()
        {
            NTypeMatrix a = new NTypeMatrix(3);
            NTypeMatrix b = new NTypeMatrix(4);
            NTypeMatrix c = a + b;
        }

        [DataTestMethod]
        [DataRow(1)]
        [DataRow(2)]
        [DataRow(3)]
        [DataRow(4)]
        public void MatrixAdditionCommutative(int size)
        {
            NTypeMatrix a = new NTypeMatrix(size);
            NTypeMatrix b = new NTypeMatrix(size);
            Assert.IsTrue((a + b).Equals(b + a));
        }
        [DataTestMethod]
        [DataRow(1)]
        [DataRow(2)]
        [DataRow(3)]
        [DataRow(4)]
        public void MatrixAdditionAssociative(int size)
        {
            NTypeMatrix a = new NTypeMatrix(size);
            NTypeMatrix b = new NTypeMatrix(size);
            NTypeMatrix c = new NTypeMatrix(size);
            Assert.IsTrue(((a + b) + c).Equals(a + (b + c)));
        }
        #endregion

        #region MULTIPLICATION

        [TestMethod]
        [ExpectedException(typeof(IncompatibleMatrixDimensionException))]
        public void MatrixMultiplicationIncompatibaleSize()
        {
            NTypeMatrix a = new NTypeMatrix(3);
            NTypeMatrix b = new NTypeMatrix(4);
            NTypeMatrix c = a * b;
        }

        [DataTestMethod]
        [DataRow(1)]
        [DataRow(2)]
        [DataRow(3)]
        [DataRow(4)]
        public void MatriMultiplicationCommutative(int size)
        {
            NTypeMatrix a = new NTypeMatrix(size);
            NTypeMatrix b = new NTypeMatrix(size);
            Assert.IsTrue((a * b).Equals(b * a));
        }
        [DataTestMethod]
        [DataRow(1)]
        [DataRow(2)]
        [DataRow(3)]
        [DataRow(4)]
        public void MatrixMultiplicationAssociative(int size)
        {
            NTypeMatrix a = new NTypeMatrix(size);
            NTypeMatrix b = new NTypeMatrix(size);
            NTypeMatrix c = new NTypeMatrix(size);
            Assert.IsTrue(((a * b) * c).Equals(a * (b * c)));
        }
        #endregion
    }
}