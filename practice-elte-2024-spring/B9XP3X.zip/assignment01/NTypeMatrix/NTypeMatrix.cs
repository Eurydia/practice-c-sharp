#pragma warning disable IDE0090

namespace NTypeMatrixServices
{
  public class NTypeMatrix
  {
    #region EXCEPTIONS
    public class InvalidMatrixSizeException : ArgumentException { }
    public class IncompatibleMatrixDimensionException : ArgumentException
    { }
    public class MatrixIndexOutOfRange : ArgumentException
    { }
    #endregion

    #region ATTRIBUTES
    private readonly List<int> elements;
    #endregion
    #region PROPERTY
    public int Size
    {
      get
      {
        return (elements.Count + 2) / 3;
      }
    }
    #endregion

    #region CONSTRUCTOR
    public NTypeMatrix(int size)
    {
      if (size <= 0)
      {
        throw new InvalidMatrixSizeException();
      }
      int capacity = (3 * size) - 2;
      elements = new List<int>(capacity);
      for (int i = 0; i < capacity; i++)
      {
        elements.Add(1);
      }
    }
    #endregion

    #region QUERIES
    private int CoordToIndex(int row, int col)
    {
      if (col == 0)
      {
        return row;
      }
      if (col == (this.Size - 1))
      {
        return this.Size + row;
      }
      if (col == row)
      {
        return (2 * this.Size) + (row - 1);
      }
      return -1;
    }
    #endregion

    #region SETTER & GETTER
    public override int GetHashCode()
    {
      return base.GetHashCode() << 2;
    }
    public override bool Equals(object? obj)
    {
      if (obj == null || !(obj is NTypeMatrix))
      {
        return false;
      }
      NTypeMatrix mat = (obj as NTypeMatrix)!;
      if (Size != mat.Size)
      {
        return false;
      }
      for (int i = 0; i < Size; i++)
      {
        if (!elements[i].Equals(mat.elements[i]))
        {
          return false;
        }
      }
      return true;
    }
    public override string ToString()
    {
      string result = "";
      for (int row = 0; row < this.Size; row++)
      {
        for (int col = 0; col < this.Size; col++)
        {
          result += String.Format("\t{0}", Get(row, col));
        }
        result += "\n";
      }
      return result;
    }
    public int Get(int row, int col)
    {
      if (col >= Size || col < 0)
      {
        throw new MatrixIndexOutOfRange();
      }
      if (row >= Size || row < 0)
      {
        throw new MatrixIndexOutOfRange();
      }
      int index = CoordToIndex(row, col);
      if (index == -1)
      {
        return 0;
      }
      return elements.ElementAt(index);
    }
    private void Set(int row, int col, int element)
    {
      int index = CoordToIndex(row, col);
      if (index == -1)
      {
        return;
      }
      elements[index] = element;
    }
    #endregion

    #region OPERATORS
    public static NTypeMatrix operator +(NTypeMatrix l, NTypeMatrix r)
    {
      int size = l.Size;
      if (size != r.Size)
      {
        throw new IncompatibleMatrixDimensionException();
      }

      NTypeMatrix result = new NTypeMatrix(size);
      for (int i = 0; i < size; i++)
      {
        result.Set(i, 0, l.Get(i, 0) + r.Get(i, 0));
        result.Set(i, i, l.Get(i, i) + r.Get(i, i));
        result.Set(i, size - 1, l.Get(i, size - 1) + r.Get(i, size - 1));
      }
      return result;
    }
    // public static NTypeMatrix operator *(NTypeMatrix mat, int k)
    // {
    //   int size = mat.Size;
    //   NTypeMatrix result = new NTypeMatrix(size);
    //   for (int i = 0; i < size; i++)
    //   {
    //     result.Set(i, 0, mat.Get(i, 0) * k);
    //     result.Set(i, i, mat.Get(i, i) * k);
    //     result.Set(i, size - 1, mat.Get(i, size - 1) * k);
    //   }
    //   return result;
    // }
    public static NTypeMatrix operator *(NTypeMatrix l, NTypeMatrix r)
    {
      if (l.Size != r.Size)
      {
        throw new IncompatibleMatrixDimensionException();
      }
      int size = l.Size;
      NTypeMatrix result = new NTypeMatrix(size);
      for (int i = 0; i < size; i++)
      {
        for (int j = 0; j < size; j++)
        {
          int sum = 0;
          if (i == j || j == 0 || j == (size - 1))
          {
            for (int k = 0; k < size; k++)
            {
              sum += l.Get(i, k) * r.Get(k, j);
            }
          }
          result.Set(i, j, sum);
        }
      }
      return result;
    }
    #endregion
  }
}