﻿// Implement the N matrix type which contains integers. These are
// square matrices that can contain nonzero entries only in their first
// and last column, and in their main diagonal. Don't store the zero
// entries. Store only the entries that can be nonzero in a sequence.
// Implement as methods: getting the entry located at index (i, j),
// adding and multiplying two matrices, and printing the matrix (in a
// square shape).

namespace NTypeMatrixServices
{
  class Program
  {
    public static void Main(String[] args)
    {
      Menu m = new Menu();
      m.Run();
    }
  }
}